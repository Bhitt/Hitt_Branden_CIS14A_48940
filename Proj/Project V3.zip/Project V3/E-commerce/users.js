// JavaScript Document
/* 
 * Branden Hitt
 * November 16th, 2015
 * Note:  Password = name
 */
users=[
        {  name:"Branden#1",
           email:"Branden#1@gmail.com",
           pswd:"1275ad638f605895a8900312d8693c02c2ce36ca"
        },
        {  name:"Branden#2",
           email:"Branden#2@gmail.com",
           pswd:"08fbd07bfee76030eca233468820b3730cbd55ac"
        },
        {  name:"Branden#3",
           email:"Branden#3@gmail.com",
           pswd:"922b996c0603f53475b7458f5ccfdd77d28d2a04"
        },
        {  name:"Branden#4",
           email:"Branden#4@gmail.com",
           pswd:"36773293c627a3bad55c1135fe754adb7a7012cc"
        },
        {  name:"Branden#5",
           email:"Branden#5@gmail.com",
           pswd:"05ae5a862a34f6e66d113ae5103d3daa6039743a"
        },
        {  name:"Branden#6",
           email:"Branden#6@gmail.com",
           pswd:"42c39ad185523771818272235122ef5f12b35db9"
        },
        {  name:"Branden#7",
           email:"Branden#7@gmail.com",
           pswd:"d92cd139fae1bc49f26060c86cdde717136da9e5"
        },
        {  name:"Branden#8",
           email:"Branden#8@gmail.com",
           pswd:"5a7d5555677e9f92a89b22997608a66edc19dd42"
        },
        {  name:"Branden#9",
           email:"Branden#9@gmail.com",
           pswd:"329f926738b824360a129fce8afffe1e8c74357e"
        },
        {  name:"Branden#10",
           email:"Branden#10@gmail.com",
           pswd:"85eaea7dcd076b1aa7d373d80c91f3b4092824f0"
        },
        {  name:"Branden#11",
           email:"Branden#11@gmail.com",
           pswd:"4a2cdb95b46564e741f68450f4eb0ef1ae190489"
        },
        {  name:"Branden#12",
           email:"Branden#12@gmail.com",
           pswd:"43759b4b4c8b877c8edbc5ff87198b5dcce0cd6c"
        },
        {  name:"Branden#13",
           email:"Branden#13@gmail.com",
           pswd:"e73609c48853efc271fa4d461a984ded82f54ec6"
        }
];